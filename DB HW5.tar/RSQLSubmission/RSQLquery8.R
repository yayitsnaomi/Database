#R SQL BONUS

#Install required R packages
install.packages("sqldf")
install.packages("XLConnect")
library(sqldf)
library(XLConnect)

#Connect to DB and read in HW 5 file
dbcon <- dbConnect(SQLite(), dbname="music.sqlite")
hw5_original <- read.csv("hw5_original.csv") 

#Write data to table
dbWriteTable(conn = dbcon, name = "hw5_original", value = hw5_original, row.names = FALSE,overwrite = TRUE)
dbListTables(dbcon)

# Delete tables if they exist in the database
dbSendQuery(conn = dbcon,"drop table if exists media_types;")
dbSendQuery(conn = dbcon,"drop table if exists genre;")
dbSendQuery(conn = dbcon,"drop table if exists artist;")
dbSendQuery(conn = dbcon,"drop table if exists album;")
dbSendQuery(conn = dbcon,"drop table if exists Customer;")
dbSendQuery(conn = dbcon,"drop table if exists Invoice;")
dbSendQuery(conn = dbcon,"drop table if exists tracks;")
dbSendQuery(conn = dbcon,"drop table if exists Invoice_items;")

# Create required tables in database
dbSendQuery(conn = dbcon,"create table media_types ( 
            mediaTypeId integer not null primary key autoincrement, 
            mediaName varchar(50) not null   );")
dbSendQuery(conn = dbcon,"create table genre(
            genreId integer not null primary key autoincrement, 
            name varchar(50) not null);")
dbSendQuery(conn = dbcon,"create table artist(
            artistId integer not null primary key autoincrement, 
            artistName TEXT UNIQUE not null);")
dbSendQuery(conn = dbcon,"create table album(
            albumId integer not null primary key autoincrement,
            albumTitle TEXT NOT NULL,
            artistId integer  NOT NULL,
            FOREIGN KEY (artistId) REFERENCES artist(artistId));")
dbSendQuery(conn = dbcon,"create table Customer(
            customerId integer not null primary key autoincrement,
            firstName varchar(25) not null, 
            lastName varchar(25) UNIQUE not null, 
            address varchar(80), 
            city varchar(40), 
            state varchar(10), 
            country varchar(20), 
            postalCode varchar(15), 
            phoneNumber varchar(25), 
            faxNumber varchar(25), 
            email varchar(50) not null );")
dbSendQuery(conn = dbcon,"create table Invoice(
            InvoiceId INTEGER NOT NULL PRIMARY KEY,
            InvoiceDate TEXT NOT NULL,
            billingAddress varchar(80), 
            billingCity varchar(40), 
            billingState varchar(10), 
            billingCountry varchar(20), 
            billingPostalCode varchar(15), 
            customerId INTEGER NOT NULL , 
            FOREIGN KEY (customerId) REFERENCES Customer(customerId));")
dbSendQuery(conn = dbcon,"create table tracks(
            trackId INTEGER NOT NULL PRIMARY KEY autoincrement, 
            trackName TEXT not null, 
            composer TEXT, 
            trackSizeByte integer, 
            trackLength integer not null, 
            trackprice integer not null, 
            genreId integer not null, 
            mediaTypeid integer not null, 
            albumId integer not null, 
            FOREIGN KEY (genreId) REFERENCES genre(genreId), 
            FOREIGN KEY (mediaTypeid) REFERENCES media_types(mediaTypeid),  
            FOREIGN KEY (albumId) REFERENCES album(albumId)
            UNIQUE(trackName, trackLength) );")
dbSendQuery(conn = dbcon,"create table Invoice_items(
            InvoiceItemId INTEGER NOT NULL PRIMARY KEY autoincrement, 
            InvoiceId integer not null, 
            trackId integer not null, 
            quantity integer not null, 
            unitPrice integer not null, 
            FOREIGN KEY (InvoiceId) REFERENCES Invoice(InvoiceId), 
            FOREIGN KEY (trackId) REFERENCES tracks(trackId) );")

# Insert statements
dbSendQuery(conn = dbcon,"insert into media_types (mediaName)
            select distinct mediaType from hw5_original;")
dbSendQuery(conn = dbcon,"insert into genre (name)
            select distinct Genre from hw5_original;")
dbSendQuery(conn = dbcon,"insert into artist (artistName)
            select distinct ArtistName from hw5_original
            where ArtistName is not null and ArtistName != '';")
dbSendQuery(conn = dbcon,"insert into album (albumTitle, artistId)
            select AlbumTitle, a.artistId 
            from hw5_original as h 
            left join artist as a on h.ArtistName = a.artistName 
            where AlbumTitle is not null and AlbumTitle != ''
            group by AlbumTitle;")
dbSendQuery(conn = dbcon,"insert into Customer (firstName,lastName,address, city, state, country, postalCode,phoneNumber,faxNumber,  email)
            select CustomerFirstName, 
            CustomerLastName, 
            CustomerAddress, 
            CustomerCity,
            CustomerState,
            CustomerCountry,
            CustomerPostalCode,
            CustomerPhone,
            CustomerFax,
            CustomerEmail
            from hw5_original
            where CustomerFirstName is not null and CustomerFirstName != ''
            group by CustomerLastName; ")
dbSendQuery(conn = dbcon,"insert into Invoice (InvoiceId, InvoiceDate, billingAddress, billingCity, billingState, billingCountry, billingPostalCode, customerId)
            SELECT h.invoiceId as InvoiceId, 
            date(invoiceDate) as invoiceDate,
            InvoiceBillingAddress as billingAddress,
            InvoiceBillingCity AS billingCity,
            InvoiceBillingState AS billingState, 
            InvoiceBillingCountry AS billingCountry,
            InvoiceBillingPostalCode AS billingPostalCode,
            z.customerId AS customerId
            FROM hw5_original as h
            LEFT JOIN (SELECT InvoiceId, c.customerId
            FROM hw5_original AS h
            JOIN Customer AS c ON h.CustomerLastName = c.lastName
            WHERE h.CustomerLastName IS NOT NULL AND h.CustomerLastName != ''
            GROUP BY InvoiceId) as z
            ON h.InvoiceId = z.InvoiceId
            WHERE h.invoiceDate IS NOT NULL AND h.invoiceDate != ''
            GROUP BY h.invoiceId; ")
dbSendQuery(conn = dbcon,"insert into tracks (trackName, composer, trackSizeByte, trackLength, trackprice, genreId, mediaTypeid, albumId)
            SELECT  h.TrackName as trackName,  
            h.Composer as composer, 
            h.TrackSizeBytes as trackSizeByte, 
            h.TrackLength as trackLength, 
            h.TrackPrice as trackprice, 
            ge.genreId as genreId, 
            mt.mediaTypeId as mediaTypeId, 
            al.albumId as albumId 
            FROM hw5_original as h 
            left join (select h.TrackName, a.albumId from hw5_original as h 
            join album as a on h.AlbumTitle = a.albumTitle 
            where h.AlbumTitle is not null and h.AlbumTitle != '' 
            group by h.TrackName) as al  
            on  h.trackName = al.TrackName 
            left join (select h.TrackName, a.mediaTypeId from hw5_original as h 
            join media_types as a on h.MediaType = a.mediaName 
            where h.MediaType is not null and h.MediaType != ''
            group by h.TrackName) as mt 
            on h.trackName = mt.TrackName 
            left join (select h.TrackName, a.genreId from hw5_original as h 
            join genre as a on h.Genre = a.name 
            where h.Genre is not null and h.Genre != ''
            group by h.TrackName) as ge 
            on h.trackName = ge.TrackName 
            where h.trackName is not null and h.trackName != '' 
            group by h.trackName,h.TrackLength;")
dbSendQuery(conn = dbcon,"insert into Invoice_items (InvoiceId, trackId, quantity, unitPrice)
            SELECT  InvoiceId, 
            t.trackId as trackId, 
            InvoiceItemQuantity as quantity, 
            InvoiceItemUnitPrice as unitPrice 
            FROM hw5_original as h 
            left join tracks as t on h.TrackName = t.trackName 
            where h.InvoiceId is not null and h.InvoiceId != '';")

#view tables and disconnect form DB
dbListTables(dbcon)
dbDisconnect(dbcon)
